import { StyleSheet, View, Text, TouchableOpacity } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { navigate } from 'expo-router/build/global-state/router'
import { useAutenticacao } from '@/hooks/useAutenticacao'
import { Drawer } from 'expo-router/drawer'

export default function Dashboard(){

    const { usuarioContexto } = useAutenticacao()

    const Cadastro= () => {
          navigate('/CadastroProdutos')
      }

    return(
        <SafeAreaView style={estilos.conteiner}>

            <Drawer.Screen options={{ title: 'Início / Dashboard' }} />
            <View style={estilos.card}>


                <View style={estilos.quadrado}>
                <Text style={estilos.tituloCard}>TOTAL DE PRODUTOS</Text>
                <Text style={estilos.valorCard}>100</Text>
                <Text style={estilos.descricaoCard}>PRODUTOS CADASTRADOS</Text>
                </View>

                <View style={estilos.quadrado}>
                <Text style={{fontSize: 20, fontWeight: 'bold', color: 'white', marginBottom: 10, textAlign: 'center'}}>TESTE</Text>
                <Text style={{fontSize: 16, color: 'white', marginBottom: 20,}}></Text>
                </View>

                <View>
                <TouchableOpacity style={estilos.botao}>
                    <Text onPress={Cadastro} >Cadastro de Produtos</Text>
                </TouchableOpacity>
                </View>
            </View>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({
    conteiner: {
        flex: 1,
        backgroundColor: 'white',
    },
    card: {
        flex: 1,
        backgroundColor: '#FF8C00',
        borderRadius: 15,
        padding: 15,
        margin: 10,
    },
    botao: {
        backgroundColor: '#e2e0de',
        paddingVertical: 14,
        paddingHorizontal: 25,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 8,
    },
    quadrado: {
        width: 190,
        height: 155,
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#F2E3D5',
        padding: 16,
        margin: 6,
        justifyContent: 'flex-start',
    },
    tituloCard: {
        fontSize: 15,
        fontWeight: '700',
        color: '#A66A32',
        textTransform: 'uppercase',
        marginBottom: 5,
    },

    valorCard: {
        fontSize: 35,
        fontWeight: '700',
        color: '#171717',
        lineHeight: 28,
    },

    descricaoCard: {
        fontSize: 15,
        color: '#C47A35',
        marginTop: 4,
    },
})
